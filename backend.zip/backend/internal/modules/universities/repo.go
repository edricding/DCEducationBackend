package universities

import (
	"context"
	"fmt"
	"strings"

	"github.com/jmoiron/sqlx"
)

type Repo struct {
	db *sqlx.DB
}

func NewRepo(db *sqlx.DB) *Repo {
	return &Repo{db: db}
}

type SearchParams struct {
	CountryCode string
	Q           string
	Page        int
	Size        int
}

func (r *Repo) Search(ctx context.Context, p SearchParams) ([]University, int, error) {
	// pagination defaults
	if p.Page <= 0 {
		p.Page = 1
	}
	if p.Size <= 0 || p.Size > 100 {
		p.Size = 20
	}
	offset := (p.Page - 1) * p.Size

	where := []string{"1=1"}
	args := map[string]interface{}{}

	if p.CountryCode != "" {
		where = append(where, "country_code = :country_code")
		args["country_code"] = strings.ToUpper(strings.TrimSpace(p.CountryCode))
	}
	if q := strings.TrimSpace(p.Q); q != "" {
		// 简单关键词：搜中英文名和简称
		where = append(where, "(name_en LIKE :q OR name_en_short LIKE :q OR name_cn LIKE :q)")
		args["q"] = "%" + q + "%"
	}

	whereSQL := strings.Join(where, " AND ")

	// total
	countSQL := fmt.Sprintf("SELECT COUNT(*) FROM universities WHERE %s", whereSQL)
	countStmt, err := r.db.PrepareNamedContext(ctx, countSQL)
	if err != nil {
		return nil, 0, err
	}
	defer countStmt.Close()

	var total int
	if err := countStmt.GetContext(ctx, &total, args); err != nil {
		return nil, 0, err
	}

	// list
	listSQL := fmt.Sprintf(`
SELECT id, country_code, country, name_en, name_en_short, name_cn, domains_json
FROM universities
WHERE %s
ORDER BY country_code, name_en
LIMIT %d OFFSET %d
`, whereSQL, p.Size, offset)

	listStmt, err := r.db.PrepareNamedContext(ctx, listSQL)
	if err != nil {
		return nil, 0, err
	}
	defer listStmt.Close()

	var items []University
	if err := listStmt.SelectContext(ctx, &items, args); err != nil {
		return nil, 0, err
	}

	return items, total, nil
}

func (r *Repo) GetByID(ctx context.Context, id uint64) (*University, error) {
	var u University
	err := r.db.GetContext(ctx, &u, `
SELECT id, country_code, country, name_en, name_en_short, name_cn, domains_json
FROM universities
WHERE id = ?
LIMIT 1
`, id)
	if err != nil {
		return nil, err
	}
	return &u, nil
}


func (r *Repo) ListAllNameCN(ctx context.Context) ([]string, error) {
	var names []string
	err := r.db.SelectContext(ctx, &names, `
SELECT name_cn
FROM universities
WHERE name_cn IS NOT NULL AND name_cn <> ''
ORDER BY name_cn
`)
	if err != nil {
		return nil, err
	}
	return names, nil
}


type OptionsCNParams struct {
	Q    string
	Page int
	Size int
}

func (r *Repo) OptionsCN(ctx context.Context, p OptionsCNParams) ([]UniversityOptionCNDTO, int, error) {
	if p.Page <= 0 {
		p.Page = 1
	}
	if p.Size <= 0 || p.Size > 200 {
		p.Size = 20
	}
	offset := (p.Page - 1) * p.Size

	where := "name_cn IS NOT NULL AND name_cn <> ''"
	args := map[string]interface{}{}

	if strings.TrimSpace(p.Q) != "" {
		where += " AND name_cn LIKE :q"
		args["q"] = "%" + strings.TrimSpace(p.Q) + "%"
	}

	// total
	countSQL := "SELECT COUNT(*) FROM universities WHERE " + where
	countStmt, err := r.db.PrepareNamedContext(ctx, countSQL)
	if err != nil {
		return nil, 0, err
	}
	defer countStmt.Close()

	var total int
	if err := countStmt.GetContext(ctx, &total, args); err != nil {
		return nil, 0, err
	}

	// list
	listSQL := fmt.Sprintf(`
SELECT id, name_cn
FROM universities
WHERE %s
ORDER BY name_cn
LIMIT %d OFFSET %d
`, where, p.Size, offset)

	listStmt, err := r.db.PrepareNamedContext(ctx, listSQL)
	if err != nil {
		return nil, 0, err
	}
	defer listStmt.Close()

	var items []UniversityOptionCNDTO
	if err := listStmt.SelectContext(ctx, &items, args); err != nil {
		return nil, 0, err
	}

	return items, total, nil
}
